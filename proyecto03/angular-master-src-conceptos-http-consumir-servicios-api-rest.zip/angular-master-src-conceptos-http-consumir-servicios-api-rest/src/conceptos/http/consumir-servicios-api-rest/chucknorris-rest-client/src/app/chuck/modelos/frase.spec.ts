import { Frase } from './frase';

describe('Frase', () => {
  it('should create an instance', () => {
    expect(new Frase()).toBeTruthy();
  });
});
